
<footer id="contactus" style="background-color: #1f1f1f;"  >
	
   
    <div class="container row" style="width:100%">
	<div class="col-md-4 col-md-offset-2">
	
	<p style="color: aqua" class="footer-links">
			<a style="color: aqua" href="#intro">About Us : </a>  
			<p>The Online Campus Selection System developed for HR Department with including automate the functioning of HR Department. This system is helpful for HR Department to make easy student selection process. We  can say this system similar to Human Resource Management System.</p>
			<br>
<p>The online campus selection software work at college or university. The College invited to recruiter/company for register in this system and help to get employee easily as per their qualification and requirements. Other hand college has all the student data submitted in this system so student can get easily job. The system is a mutual place for student and company. The online campus selection system helps student to get job and company to get employee.</p>
            <h3 style="color: aqua"><a href=""><h3 style="font-family:audiowide;display:inline"></h3> </a></h3>
		
          
		
		
    </div>
    
    
    <div class="col-md-3 col-md-offset-3">
			<div id="contact" class="container-fluid bg-grey">
                            <h2 class="text-center " style="font-family:Comfortaa;color:aqua">CONTACT US</h2>
  
   <br>
    <div >
      <p>Contact Us If You Have Any Doubt's</p>
      <p>Contact Person Name : Karthik Iyer</p>
      <p><span class="glyphicon glyphicon-map-marker"></span> OCSS,Khambalpada,Thakurli(East)-421201</p>
      <p><span class="glyphicon glyphicon-phone"></span> +919702086035</p>
      <p><span class="glyphicon glyphicon-envelope"></span> ocss@gmail.com</p>
    </div>
    
  
</div>
</div>
    
    </div>
	
	

	
</footer>	