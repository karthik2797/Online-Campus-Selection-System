<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<Option>SELECT YOUR DEGREE/GRADUATION</Option>
<option>MSc IT</option>
option>MSc CS</option>
<option>M Com - Accountancy</option>
<option>M Com - Management</option>
<option>M Com - Banking & Finance</option>
<option>B Com - Regular</option>
<option>B Com - Accounting & Finace</option>
<option>B Com - Banking & Insurance</option>
<option>BMS</option>
<option>BMM</option>
<option>B Sc - Information Technology</option>
<option>B Sc - Computer Science</option>
<option>B Sc - Life Science</option>
<option>B Sc - Chemistry</option>
<option>B Sc - Biotechnology</option>
<option>LLB</option>
<option>BBA</option>
<option>LLM</option>
<option>MMS</option>
<option>MBA</option>
<option>MSC</option>
<option>others</option>